using Godot;
using System;

public partial class Global : Node
{
	public int high_score = 0;
	public int current_score = 0;
}
